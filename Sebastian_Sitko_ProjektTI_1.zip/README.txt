Projekt wykorzystuje fizyczne w�a�ciwo�ci rzutu parabolicznego, prezentuj�c go na przykadzie prostej gry stworzonej z wykorzystaniem <canvas>
Obliczenia matematyczne s� wykonywane po stronie servera, przy pomocy skryptu python.

Technologia WebWorker zosta�a zastosowana jako licznik czasu do zako�czenia rozgrywki.


Strona by�a testowana w przegl�darce firefox.